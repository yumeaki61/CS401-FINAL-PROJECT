import React from 'react';
import { Button, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ClearUserDataButton = () => {
  const handleClearUserData = async () => {
    try {
      await AsyncStorage.removeItem('userEmail');
      await AsyncStorage.removeItem('userPassword');
      Alert.alert('Success', 'User data cleared successfully');
    } catch (error) {
      console.error('Error clearing user data:', error);
      Alert.alert('Error', 'Failed to clear user data');
    }
  };

  return <Button title="Clear User Data" onPress={handleClearUserData} />;
};

export default ClearUserDataButton;
