import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Modal } from 'react-native';
import { ProgressSteps, ProgressStep } from 'react-native-progress-steps';
import AsyncStorage from '@react-native-async-storage/async-storage';
import coffee1 from './assets/BT5.png'; // Import coffee1 image
import coffee2 from './assets/BT2.png'; // Import coffee2 image
import coffee3 from './assets/BT3.png'; // Import coffee3 image
import coffee4 from './assets/BT4.png'; // Import coffee4 image
import coffee5 from './assets/BT6.png'; // Import coffee5 image
import coffee6 from './assets/BT7.png'; // Import coffee6 image
import coffee7 from './assets/BT8.png'; // Import coffee7 image
import coffee8 from './assets/BT9.png'; // Import coffee8 image

const coffeeImages = {
  'Jo Malone': coffee1,
  'D&G Light Blue': coffee2,
  'Chloé': coffee3,
  'Marc Jacobs': coffee4,
  'Eclat d’Arpège': coffee5,
  'Replica': coffee6,
  'Gucci Bloom': coffee7,
  'D&G Devotion': coffee8,
};

const CheckoutScreen = ({ route }) => {
  const [progress, setProgress] = useState(0);
  const [modalVisible, setModalVisible] = useState(false);
  const [checkedOutItems, setCheckedOutItems] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);
  const [userInfo, setUserInfo] = useState({});
  const [modalType, setModalType] = useState(null);

  useEffect(() => {
    // Simulate progress at intervals
    const interval = setInterval(() => {
      setProgress((prevProgress) => prevProgress + 1); // Update progress by one
    }, 3000); // Change the progress every 3 seconds

    // Load checked out items from AsyncStorage
    fetchCheckedOutItems();

    // Fetch user info from AsyncStorage
    fetchUserInfo();

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Calculate total price of all items
    let total = 0;
    checkedOutItems.forEach((item) => {
      total += item.price * item.quantity;
    });
    setTotalPrice(total);
  }, [checkedOutItems]);

  const fetchCheckedOutItems = async () => {
    try {
      const items = await AsyncStorage.getItem('cart');
      console.log('Fetched items:', items); // Log fetched items
      if (items !== null) {
        setCheckedOutItems(JSON.parse(items));
      }
    } catch (error) {
      console.error('Error fetching checked out items:', error);
    }
  };

  const fetchUserInfo = async () => {
    try {
      const userData = await AsyncStorage.getItem('userInfo');
      if (userData !== null) {
        setUserInfo(JSON.parse(userData));
      }
    } catch (error) {
      console.error('Error fetching user info:', error);
    }
  };

  const handleModalOpen = () => {
    setModalType('summary');
    setModalVisible(true);
  };

  const handleUserInfoModalOpen = () => {
    setModalType('userInfo');
    setModalVisible(true);
  };

  const handleModalClose = () => {
    setModalVisible(false);
  };

  return (
    <View style={styles.container}>
      <ProgressSteps
        activeStep={progress}
        disabledStepNumColor="#999999"
        activeStepIconBorderColor="#c68f7d" // Change ProgressStep color to brown
        // Change text color to white
        activeStepIconColor="white" // Change icon color to white
        completedStepIconColor="#5B4F47" // Change completed step icon color to white
        completedProgressBarColor="#5B4F47" // Change completed progress bar color to brown
      >
        <ProgressStep label="Preparing" removeBtnRow={true} activeLabelColor="brown">
          <View style={styles.stepContent}>
            <Image source={require('./assets/prepare.png')} style={styles.image} />
            <Text style={styles.stepText}>Preparing your order...</Text>
          </View>
        </ProgressStep>
        <ProgressStep label="Ready for Pickup" removeBtnRow={true}>
          <View style={styles.stepContent}>
            <Image source={require('./assets/PKUP.png')} style={styles.image} />
            <Text style={styles.stepText}>Order is ready for pickup.</Text>
          </View>
        </ProgressStep>
        <ProgressStep label="On the Way" removeBtnRow={true}>
          <View style={styles.stepContent}>
            <Image source={require('./assets/otw.png')} style={styles.image} />
            <Text style={styles.stepText}>Order picked up. On the way...</Text>
          </View>
        </ProgressStep>
        <ProgressStep label="Delivered" removeBtnRow={true}>
          <View style={styles.stepContent}>
            <Image source={require('./assets/DELIVERED.png')} style={styles.image} />
            <Text style={styles.stepText}>Order delivered. Enjoy your meal!</Text>
          </View>
        </ProgressStep>
      </ProgressSteps>

      <TouchableOpacity style={styles.userInfoButton} onPress={handleUserInfoModalOpen}>
        <Text style={styles.userInfoButtonText}>User Info</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.summaryButton} onPress={handleModalOpen}>
        <Text style={styles.summaryButtonText}>Order Summary</Text>
      </TouchableOpacity>

      <Text style={styles.totalText}>Total: ₱{totalPrice}</Text>

      <Modal animationType="slide" transparent={true} visible={modalVisible} onRequestClose={handleModalClose}>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            {modalType === 'summary' && (
              <>
                <Text style={styles.modalTitle}>Order Summary</Text>
                {checkedOutItems.map((item, index) => (
                  <View key={index} style={styles.orderItem}>
                    <Image source={coffeeImages[item.title]} style={styles.itemImage} />
                    <View style={styles.itemDetails}>
                      <Text style={styles.itemTitle}>{item.title}</Text>
                      <Text style={styles.itemPrice}>₱{item.price}</Text>
                    </View>
                  </View>
                ))}
                <Text style={styles.totalPrice}>Total Price: ₱{totalPrice}</Text>
              </>
            )}
            {modalType === 'userInfo' && (
              <>
                <Text style={styles.modalTitle}>User Information</Text>
                <Text>Name: {userInfo.name}</Text>
                <Text>Address: {userInfo.address}</Text>
                <Text>Contact Number: {userInfo.contactNumber}</Text>
                <Text>Payment Method: {userInfo.paymentMethod}</Text>
              </>
            )}
            <TouchableOpacity style={styles.closeButton} onPress={handleModalClose}>
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    backgroundColor: '#EDDACF', // Change background color to black
  },
  stepContent: {
    alignItems: 'center',
  },
  image: {
    width: 300,
    height: 300,
    marginBottom: 20,
  },
  stepText: {
    fontSize: 18,
    textAlign: 'center',
    color: 'white', // Change text color to white
  },
  userInfoButton: {
    backgroundColor: '#c68f7d', // Change button color to brown
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 10,
    marginBottom: 20,
  },
  userInfoButtonText: {
    color: 'white', // Change text color to white
    fontSize: 18,
    fontWeight: 'bold',
  },
  summaryButton: {
    backgroundColor: '#c68f7d', // Change button color to brown
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 10,
    marginBottom: 20,
  },
  summaryButtonText: {
    color: 'white', // Change text color to white
    fontSize: 18,
    fontWeight: 'bold',
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white', // Change text color to white
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
    color: 'black',
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  orderItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  itemImage: {
    width: 80,
    height: 80,
    borderRadius: 10,
    marginRight: 10,
  },
  itemDetails: {
    flex: 1,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: 'black', // Change text color to black
  },
  itemPrice: {
    fontSize: 14,
    color: 'black', // Change text color to black
  },
  totalPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
  },
  closeButton: {
    backgroundColor: '#c68f7d', // Change button color to brown
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginTop: 20,
  },
  closeButtonText: {
    color: 'white', // Change text color to white
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default CheckoutScreen;
