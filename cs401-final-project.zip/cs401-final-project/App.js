import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import LoginScreen from './LoginScreen';
import RegisterScreen from './RegisterScreen';
import HomeScreen from './HomeScreen';
import SettingsScreen from './SettingsScreen';
import CartScreen from './CartScreen';
import CheckoutScreen from './CheckoutScreen';
import { Image, TouchableOpacity, View, Text } from 'react-native'; // Import TouchableOpacity and View from react-native
import AsyncStorage from '@react-native-async-storage/async-storage'; // Import AsyncStorage

const Stack = createStackNavigator();

function App() {
  const clearCartItems = async () => {
    try {
      await AsyncStorage.removeItem('cart');
      console.log('Cart items cleared successfully.');
    } catch (error) {
      console.error('Error clearing cart items:', error);
    }
  };

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Register" component={RegisterScreen} />
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={({ navigation }) => ({
            headerRight: () => (
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity onPress={() => navigation.navigate('Settings')}>
                  <Image source={require('./assets/profile.png')} style={{ width: 45, height: 45, marginRight: 10 }} />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => navigation.navigate('Cart')}>
                  <Image source={require('./assets/cart.png')} style={{ width: 45, height: 45, marginRight: 10 }} />
                </TouchableOpacity>
              </View>
            ),
            headerLeft: () => (
              <TouchableOpacity onPress={() => navigation.navigate('Home')}>
                 <Image source={require('./assets/LOGOO.png')} style={{ width: 70, height: 70, marginLeft: 10 }} />
              </TouchableOpacity>
            ),
          })}
        />
        <Stack.Screen name="Settings" component={SettingsScreen} />
        <Stack.Screen name="Cart" component={CartScreen} />
        <Stack.Screen
          name="Checkout"
          component={CheckoutScreen}
          options={({ navigation }) => ({
            title: 'Checkout',
            headerLeft: () => (
              <TouchableOpacity onPress={() => {
                clearCartItems(); // Clear cart items when navigating to home
                navigation.navigate('Home');
              }}>
                 <Image source={require('./assets/home.png')} style={{ width: 25, height: 25, marginLeft: 10 }} />
              </TouchableOpacity>
            ),
          })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
