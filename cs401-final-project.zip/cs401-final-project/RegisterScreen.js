import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, TouchableOpacity,Image, Modal } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const RegisterScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isErrorModalVisible, setIsErrorModalVisible] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isSuccessModalVisible, setIsSuccessModalVisible] = useState(false);

  const handleRegister = async () => {
    if (!validateForm()) {
      return;
    }

    try {
      // Check if the email is already registered
      const existingEmail = await AsyncStorage.getItem('userEmail');
      if (existingEmail === email) {
        setErrorMessage('Email already registered');
        setIsErrorModalVisible(true);
        return;
      }

      // Save user data to AsyncStorage
      await AsyncStorage.setItem('userEmail', email);
      await AsyncStorage.setItem('username', username);
      await AsyncStorage.setItem('userPassword', password);
      setIsSuccessModalVisible(true);
    } catch (error) {
      console.error('Error registering:', error);
      setErrorMessage('Failed to register');
      setIsErrorModalVisible(true);
    }
  };

  const validateForm = () => {
    if (!email || !username || !password || !confirmPassword) {
      setErrorMessage('Please fill in all fields');
      setIsErrorModalVisible(true);
      return false;
    }

    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match');
      setIsErrorModalVisible(true);
      return false;
    }

    return true;
  };

  const handleModalClose = () => {
    setIsErrorModalVisible(false);
    setIsSuccessModalVisible(false);
  };

  return (
    <View style={styles.container}>
    <Image source={require('./assets/LOGOO.png')} style={styles.logo} />
      <Text style={styles.heading}>Register</Text>
      <TextInput
        style={styles.input}
        placeholder="Email" placeholderTextColor="white" 
        onChangeText={(text) => setEmail(text)}
        value={email}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Username" placeholderTextColor="white" 
        onChangeText={(text) => setUsername(text)}
        value={username}
      />
      <TextInput
        style={styles.input}
        placeholder="Password" placeholderTextColor="white" 
        onChangeText={(text) => setPassword(text)}
        value={password}
        secureTextEntry
      />
      <TextInput
        style={styles.input}
        placeholder="Confirm Password" placeholderTextColor="white" 
        onChangeText={(text) => setConfirmPassword(text)}
        value={confirmPassword}
        secureTextEntry
      />
  

 <TouchableOpacity style={styles.button} onPress={handleRegister}>
  <Text style={styles.buttonText}>Register</Text>
</TouchableOpacity>
<TouchableOpacity style={styles.button} onPress={() => navigation.goBack()}>
  <Text style={styles.buttonText}>Back</Text>
</TouchableOpacity>


      <Modal visible={isErrorModalVisible} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalText}>{errorMessage}</Text>
            <TouchableOpacity onPress={handleModalClose} style={styles.button}>
              <Text style={styles.buttonText}>OK</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      <Modal visible={isSuccessModalVisible} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalText}>Registration successful!</Text>
            <TouchableOpacity onPress={handleModalClose} style={styles.button}>
              <Text style={styles.buttonText}>OK</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
     backgroundColor: '#EDDACF', 
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
     color: '#5B4F47',
  },
   logo: {
    width: 350,
    height: 350,
    marginBottom: 10,
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#5B4F47',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 10,
     color: '#5B4F47',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#5B4F47',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    elevation: 5,
  },
  modalText: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'center',
  },
 button: {
  backgroundColor: '#5B4F47',
  paddingVertical: 10,
  paddingHorizontal: 20,
  borderRadius: 5,
  marginTop: 10,
},
buttonText: {
  color: 'white',
  fontWeight: 'bold',
  textAlign: 'center',
}
});

export default RegisterScreen;
