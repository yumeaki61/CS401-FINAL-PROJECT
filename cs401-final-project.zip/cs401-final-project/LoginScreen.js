import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, TouchableOpacity, Image, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [loginError, setLoginError] = useState('');

  useEffect(() => {
    // Check if there is any registered user data in AsyncStorage
    const checkRegisteredUser = async () => {
      try {
        const storedEmail = await AsyncStorage.getItem('userEmail');
        const storedPassword = await AsyncStorage.getItem('userPassword');
        if (storedEmail && storedPassword) {
          // Redirect to Home screen or dashboard if user is already logged in
          navigation.navigate('Home');
          console.log('User is already registered:', storedEmail);
        }
      } catch (error) {
        console.error('Error checking registered user:', error);
      }
    };
    checkRegisteredUser();
}, [navigation]);

  const validateForm = () => {
    let isValid = true;
    setEmailError('');
    setPasswordError('');

    if (!email) {
      setEmailError('Email is required');
      isValid = false;
    }
    if (!password) {
      setPasswordError('Password is required');
      isValid = false;
    }
    return isValid;
  };

  const handleLogin = async () => {
    if (!validateForm()) {
      return;
    }

    try {
      const storedEmail = await AsyncStorage.getItem('userEmail');
      const storedPassword = await AsyncStorage.getItem('userPassword');
      if (storedEmail === email && storedPassword === password) {
        // Navigate to the Home screen or dashboard after successful login
        navigation.navigate('Home');
        console.log('Logged in successfully!');
      } else {
        console.log('Invalid email or password');
        setLoginError('Invalid email or password');
      }
    } catch (error) {
      console.error('Error logging in:', error);
      setLoginError('Failed to login');
    }
  };

  const handleRegister = () => {
    navigation.navigate('Register');
  };

  return (
    <View style={styles.container}>
      <Image source={require('./assets/LOGOO.png')} style={styles.logo} />
      <Text style={styles.welcomeText}>Welcome to Scentify</Text>
      <Text style={styles.tagline}>A Fragrance Tailored For Elegance</Text>
      <TextInput
        style={[styles.input, emailError && styles.inputError]}
        placeholder="Email" placeholderTextColor="white" 
        onChangeText={(text) => setEmail(text)}
        value={email}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      {emailError ? <Text style={styles.errorText}>{emailError}</Text> : null}
      <TextInput
        style={[styles.input, passwordError && styles.inputError]}
        placeholder="Password" placeholderTextColor="white" 
        onChangeText={(text) => setPassword(text)}
        value={password}
        secureTextEntry
      />
      {passwordError ? <Text style={styles.errorText}>{passwordError}</Text> : null}
      {loginError ? <Text style={styles.errorText}>{loginError}</Text> : null}

      
     <TouchableOpacity style={styles.button} onPress={handleLogin}>
  <Text style={styles.buttonText}>Login</Text>
</TouchableOpacity>
<TouchableOpacity style={styles.button} onPress={handleRegister}>
  <Text style={styles.buttonText}>Register</Text>
</TouchableOpacity>

    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    backgroundColor: '#EDDACF',
  },
  logo: {
    width: 350,
    height: 350,
    marginBottom: 10,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
    color: '#c68f7d', // Text color changed to white
  },
  tagline: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
    color: '#5B4F47', // Text color changed to white
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#5B4F47',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 10,
    color: 'black', // Text color changed to white
  },
  inputError: {
    borderColor: 'red',
  },
  errorText: {
    color: 'red',
    marginBottom: 5,
  
  },
 button: {
  backgroundColor: '#c68f7d',
  paddingVertical: 10,
  paddingHorizontal: 20,
  borderRadius: 5,
  marginTop: 10,
},
buttonText: {
  color: 'white',
  fontWeight: 'bold',
  textAlign: 'center',
}

});


export default LoginScreen;
