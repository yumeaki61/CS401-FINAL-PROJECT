import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Alert, Image, Button, Modal, TextInput } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import coffee1 from './assets/BT5.png';
import coffee2 from './assets/BT2.png';
import coffee3 from './assets/BT3.png';
import coffee4 from './assets/BT4.png';
import coffee5 from './assets/BT6.png';
import coffee6 from './assets/BT7.png';
import coffee7 from './assets/BT8.png';
import coffee8 from './assets/BT9.png';

const cartImages = {
  'Jo Malone': coffee1,
  'D&G Light Blue': coffee2,
  'Chloé': coffee3,
  'Marc Jacobs': coffee4,
  'Eclat d’Arpège': coffee5,
  'Replica': coffee6,
  'Gucci Bloom': coffee7,
  'D&G Devotion': coffee8,
};

const CartScreen = () => {
  const [cart, setCart] = useState([]);
  const [userInfo, setUserInfo] = useState({});
  const [modalVisible, setModalVisible] = useState(false);
  const [paymentMethodModalVisible, setPaymentMethodModalVisible] = useState(false);
  const [errorText, setErrorText] = useState('');
  const navigation = useNavigation();

  useEffect(() => {
    const fetchCart = async () => {
      const savedCart = await AsyncStorage.getItem('cart');
      if (savedCart) {
        setCart(JSON.parse(savedCart));
      }
    };
    fetchCart();

    const unsubscribe = navigation.addListener('focus', () => {
      setUserInfo({});
    });

    return unsubscribe;
  }, [navigation]);

  const handleDeleteItem = async (index) => {
    const updatedCart = [...cart];
    updatedCart.splice(index, 1);
    setCart(updatedCart);
    await AsyncStorage.setItem('cart', JSON.stringify(updatedCart));
    Alert.alert('Success', 'Item removed from cart.');
  };

  const handleCheckout = async () => {
    if (Object.keys(userInfo).length === 0) {
      setModalVisible(true);
    } else {
      try {
        await AsyncStorage.setItem('userInfo', JSON.stringify(userInfo));
        navigation.navigate('Checkout', { userInfo: userInfo });
      } catch (error) {
        console.error('Error saving user information:', error);
        Alert.alert('Error', 'Failed to save user information. Please try again.');
      }
    }
  };

  const handleSaveUserInfo = async () => {
    if (userInfo.name && userInfo.address && userInfo.contactNumber && userInfo.paymentMethod) {
      try {
        await AsyncStorage.setItem('userInfo', JSON.stringify(userInfo));
        setCart([]);
        setModalVisible(false);
        navigation.navigate('Checkout', { userInfo: userInfo });
      } catch (error) {
        console.error('Error saving user information:', error);
        Alert.alert('Error', 'Failed to save user information. Please try again.');
      }
    } else {
      setErrorText('Please fill out all fields.');
    }
  };

  const togglePaymentMethodModal = () => {
    setPaymentMethodModalVisible(!paymentMethodModalVisible);
  };

  const selectPaymentMethod = (method) => {
    setUserInfo({ ...userInfo, paymentMethod: method });
    togglePaymentMethodModal();
  };

  const renderPaymentMethodModal = () => (
    <Modal
      visible={paymentMethodModalVisible}
      animationType="slide"
      transparent={true}
      onRequestClose={togglePaymentMethodModal}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <TouchableOpacity style={styles.closeButton} onPress={togglePaymentMethodModal}>
            <Text style={styles.closeButtonText}>X</Text>
          </TouchableOpacity>
          <Text style={styles.modalTitle}>Choose Payment Method</Text>
          <TouchableOpacity onPress={() => selectPaymentMethod('Cash on Delivery')}>
            <Text style={styles.paymentMethodOption}>Cash on Delivery</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => selectPaymentMethod('Card')}>
            <Text style={styles.paymentMethodOption}>Card</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => selectPaymentMethod('Gcash')}>
            <Text style={styles.paymentMethodOption}>Gcash</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => selectPaymentMethod('Maya')}>
            <Text style={styles.paymentMethodOption}>Maya</Text>
          </TouchableOpacity>
          {/* Add more options as needed */}
        </View>
      </View>
    </Modal>
  );

  const totalPrice = cart.reduce((total, item) => total + parseFloat(item.price) * item.quantity, 0);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cart Items:</Text>
      {cart.length === 0 ? (
        <Text style={styles.emptyText}>Your cart is empty.</Text>
      ) : (
        <FlatList
          data={cart}
          renderItem={({ item, index }) => {
            return (
              <View style={styles.cartItemContainer}>
                <Image source={cartImages[item.title]} style={styles.productImage} />
                <View style={styles.cartItemInfo}>
                  <Text style={styles.cartItemTitle}>{item.title}</Text>
                  <Text style={styles.cartItemDetails}>Price: ₱{item.price}</Text>
                  <Text style={styles.cartItemDetails}>Cup Size: {item.cupSize}</Text>
                  <Text style={styles.cartItemDetails}>Quantity: {item.quantity}</Text>
                </View>
                <TouchableOpacity onPress={() => handleDeleteItem(index)} style={styles.deleteButton}>
                  <Text style={styles.deleteButtonText}>Remove</Text>
                </TouchableOpacity>
              </View>
            );
          }}
          keyExtractor={(item, index) => index.toString()}
          contentContainerStyle={styles.flatListContent}
        />
      )}
      <Text style={styles.totalPrice}>Total: ₱{totalPrice.toFixed(2)}</Text>
      <TouchableOpacity style={styles.checkoutButton} onPress={handleCheckout}>
        <Text style={styles.checkoutButtonText}>Checkout</Text>
      </TouchableOpacity>
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <TouchableOpacity style={styles.closeButton} onPress={() => setModalVisible(false)}>
              <Text style={styles.closeButtonText}>X</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Enter User Information</Text>
            <TextInput
              style={styles.input}
              placeholder="Name"
              value={userInfo.name}
              onChangeText={(text) => setUserInfo({ ...userInfo, name: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Address"
              value={userInfo.address}
              onChangeText={(text) => setUserInfo({ ...userInfo, address: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Contact Number"
              value={userInfo.contactNumber}
              onChangeText={(text) => setUserInfo({ ...userInfo, contactNumber: text })}
              keyboardType="phone-pad"
            />
            <TextInput
              style={styles.input}
              placeholder="Payment Method"
              value={userInfo.paymentMethod}
              onFocus={togglePaymentMethodModal}
            />
            {errorText ? <Text style={styles.errorText}>{errorText}</Text> : null}
<TouchableOpacity style={styles.saveButton} onPress={handleSaveUserInfo}>
<Text style={styles.saveButtonText}>Save Information</Text>
</TouchableOpacity>
</View>
</View>
</Modal>
{renderPaymentMethodModal()}
</View>
);
};

const styles = StyleSheet.create({
container: {
flex: 1,
paddingHorizontal: 20,
paddingTop: 20,
backgroundColor: '#EDDACF',
},
title: {
fontSize: 20,
fontWeight: 'bold',
marginBottom: 10,
color: 'white',
},
emptyText: {
fontSize: 16,
textAlign: 'center',
marginTop: 20,
color: 'white',
},
cartItemContainer: {
flexDirection: 'row',
justifyContent: 'space-between',
alignItems: 'center',
borderWidth: 1,
borderColor: '#ccc',
borderRadius: 10,
padding: 15,
marginBottom: 10,
backgroundColor: 'white',
},
productImage: {
width: 80,
height: 80,
borderRadius: 10,
marginRight: 10,
},
cartItemInfo: {
flex: 1,
},
cartItemTitle: {
fontSize: 16,
fontWeight: 'bold',
marginBottom: 5,
},
cartItemDetails: {
fontSize: 14,
marginBottom: 3,
},
deleteButton: {
backgroundColor: 'brown',
paddingVertical: 5,
paddingHorizontal: 10,
borderRadius: 5,
},
deleteButtonText: {
color: '#fff',
fontWeight: 'bold',
},
checkoutButton: {
backgroundColor: '#c68f7d',
alignItems: 'center',
justifyContent: 'center',
paddingVertical: 15,
borderRadius: 10,
marginTop: 20,
},
checkoutButtonText: {
color: '#fff',
fontSize: 18,
fontWeight: 'bold',
},
flatListContent: {
paddingBottom: 20,
},
modalContainer: {
flex: 1,
justifyContent: 'center',
alignItems: 'center',
backgroundColor: 'rgba(0, 0, 0, 0.5)',
},
modalContent: {
backgroundColor: '#fff',
padding: 20,
borderRadius: 10,
width: '80%',
alignItems: 'center',
},
modalTitle: {
fontSize: 18,
fontWeight: 'bold',
marginBottom: 20,
},
input: {
width: '100%',
height: 40,
backgroundColor: '#eee',
borderRadius: 5,
paddingHorizontal: 10,
marginBottom: 15,
},
saveButton: {
backgroundColor: '#c68f7d',
paddingHorizontal: 20,
paddingVertical: 10,
borderRadius: 5,
marginTop: 10,
},
saveButtonText: {
color: 'white',
fontWeight: 'bold',
},
closeButton: {
position: 'absolute',
top: 10,
right: 10,
},
closeButtonText: {
fontSize: 20,
fontWeight: 'bold',
},
errorText: {
color: 'red',
marginBottom: 10,
},
totalPrice: {
fontSize: 18,
fontWeight: 'bold',
marginBottom: 20,
color: 'white',
},
paymentMethodOption: {
fontSize: 16,
paddingVertical: 10,
},
});

export default CartScreen;
