import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Modal, TouchableOpacity, Image } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SettingsScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isEditMode, setIsEditMode] = useState(false);
  const [isDeleteMode, setIsDeleteMode] = useState(false);
  const [isLogoutModalVisible, setIsLogoutModalVisible] = useState(false);
  const [isSaveSuccessModalVisible, setIsSaveSuccessModalVisible] = useState(false);

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const storedEmail = await AsyncStorage.getItem('userEmail');
      const storedUsername = await AsyncStorage.getItem('username');
      const storedPassword = await AsyncStorage.getItem('userPassword');
      setEmail(storedEmail);
      setUsername(storedUsername);
      setPassword(storedPassword);
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  const handleSaveChanges = async () => {
    try {
      await AsyncStorage.setItem('userEmail', email);
      await AsyncStorage.setItem('username', username);
      await AsyncStorage.setItem('userPassword', password);
      setIsEditMode(false);
      setIsSaveSuccessModalVisible(true);
    } catch (error) {
      console.error('Error saving changes:', error);
    }
  };

  const handleDeleteAccount = () => {
    setIsDeleteMode(true);
  };

  const confirmDeleteAccount = () => {
    return (
      <Modal visible={isDeleteMode} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalText}>Are you sure you want to delete your account?</Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity onPress={deleteAccount} style={[styles.button, styles.deleteButton]}>
                <Text style={styles.buttonText}>Delete</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setIsDeleteMode(false)} style={[styles.button, styles.cancelButton]}>
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };

  const deleteAccount = async () => {
    try {
      await AsyncStorage.removeItem('userEmail');
      await AsyncStorage.removeItem('username');
      await AsyncStorage.removeItem('userPassword');
      setIsDeleteMode(false);
      navigation.navigate('Login');
    } catch (error) {
      console.error('Error deleting account:', error);
    }
  };

  const handleLogout = () => {
    setIsLogoutModalVisible(true);
  };

  const confirmLogout = () => {
    return (
      <Modal visible={isLogoutModalVisible} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalText}>Are you sure you want to logout?</Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity onPress={logout} style={[styles.button, styles.logoutButton]}>
                <Text style={styles.buttonText}>Logout</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setIsLogoutModalVisible(false)} style={[styles.button, styles.cancelButton]}>
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };

  const logout = () => {
    setIsLogoutModalVisible(false);
    navigation.navigate('Login');
  };

  const handleSaveSuccessModalClose = () => {
    setIsSaveSuccessModalVisible(false);
  };

  const renderSaveSuccessModal = () => {
    return (
      <Modal visible={isSaveSuccessModalVisible} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalText}>Changes saved successfully!</Text>
            <TouchableOpacity onPress={handleSaveSuccessModalClose} style={[styles.button, styles.successButton]}>
              <Text style={styles.buttonText}>OK</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.profileInfo}>
        <Image source={require('./assets/profile.png')} style={styles.profileIcon} />
        <View>
          <Text>Email:</Text>
          <TextInput
             style={[styles.input, { width: 200 }]}
            value={email}
            onChangeText={setEmail}
            editable={isEditMode}
          />
        </View>
        <View>
          <Text>Username:</Text>
          <TextInput
             style={[styles.input, { width: 200 }]}
            value={username}
            onChangeText={setUsername}
            editable={isEditMode}
          />
        </View>
        <View>
          <Text>Password:</Text>
          <TextInput
             style={[styles.input, { width: 200 }]}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            editable={isEditMode}
          />
        </View>
      </View>
           {isEditMode ? (
        <TouchableOpacity onPress={handleSaveChanges} style={[styles.button, styles.saveButton]}>
          <Text style={styles.buttonText}>Save Changes</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity onPress={() => setIsEditMode(true)} style={[styles.button, styles.editButton]}>
          <Text style={styles.buttonText}>Edit</Text>
        </TouchableOpacity>
      )}
      <TouchableOpacity onPress={handleDeleteAccount} style={[styles.button, styles.deleteButton]}>
        <Text style={styles.buttonText}>Delete Account</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={handleLogout} style={[styles.button, styles.logoutButton]}>
        <Text style={styles.buttonText}>Logout</Text>
      </TouchableOpacity>
      {confirmDeleteAccount()}
      {confirmLogout()}
      {renderSaveSuccessModal()}
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    backgroundColor: '#EDDACF',
  },
  profileInfo: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profileIcon: {
    width: 100,
    height: 100,
    marginBottom: 10,
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#5B4F47',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 10,
    color: '#5B4F47',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    elevation: 5,
  },
  modalText: {
    fontSize: 16,
    marginBottom: 20,

  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: 'center',
  },
  saveButton: {
    backgroundColor: '#c68f7d',
  },
  editButton: {
    backgroundColor: '#c68f7d',
  },
  deleteButton: {
    backgroundColor: '#c68f7d',
  },
  logoutButton: {
    backgroundColor: '#c68f7d',
  },
  cancelButton: {
    backgroundColor: '#c68f7d',
  },
  successButton: {
    backgroundColor: 'green',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default SettingsScreen;

