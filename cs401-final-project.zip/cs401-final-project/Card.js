import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';

const Card = ({ product, onPress }) => {
  return (
    <TouchableOpacity style={styles.productCard} onPress={() => onPress(product)}>
      <Image source={product.image} style={styles.productImage} />
      <Text style={styles.productTitle}>{product.title}</Text>
      <Text style={styles.productPrice}>{product.price}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  productCard: {
    width: 150,
    padding: 10,
    borderRadius: 10,
    backgroundColor: '#EDDACF',
    elevation: 5,
    marginBottom: 20,
  },
  productImage: {
    width: '150%',
    height: 150,
    marginBottom: 10,
    borderRadius: 10,
  },
  productTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  productPrice: {
    fontSize: 14,
    color: 'grey',
  },
});

export default Card;
