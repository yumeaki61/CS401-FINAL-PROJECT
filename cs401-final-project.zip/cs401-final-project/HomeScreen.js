import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Modal, Button } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const coffee1 = require('./assets/BT5.png');
const coffee2 = require('./assets/BT2.png');
const coffee3 = require('./assets/BT3.png');
const coffee4 = require('./assets/BT4.png');
const coffee5 = require('./assets/BT6.png');
const coffee6 = require('./assets/BT7.png');
const coffee7 = require('./assets/BT8.png');
const coffee8 = require('./assets/BT9.png');

const products = [
  { id: 1, title: 'Jo Malone', image: coffee1, price: 4600 },
  { id: 2, title: 'D&G Light Blue', image: coffee2, price: 6300 },
  { id: 3, title: 'Chloé', image: coffee3, price: 8598 },
  { id: 4, title: 'Marc Jacobs', image: coffee4, price: 5000 },
  { id: 5, title: 'Eclat d’Arpège', image: coffee5, price: 3400 },
  { id: 6, title: 'Replica', image: coffee6, price: 9000 },
  { id: 7, title: 'Gucci Bloom', image: coffee7, price: 7500 },
  { id: 8, title: 'D&G Devotion', image: coffee8, price: 8200 },
];

const HomeScreen = ({ navigation }) => {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [cupSize, setCupSize] = useState('M');
  const [quantity, setQuantity] = useState(1);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedPrice, setSelectedPrice] = useState(0);

  useEffect(() => {
    if (selectedProduct) {
      updatePrice(selectedProduct.price, cupSize);
    }
  }, [selectedProduct, cupSize]);

  useEffect(() => {
    if (selectedProduct) {
      updatePrice(selectedProduct.price, cupSize);
    }
  }, [quantity]);

  const updatePrice = (basePrice, size) => {
    let price = basePrice;
    if (size === 'S') {
      price -= 1000; // Decrease price for small cup
    } else if (size === 'L') {
      price += 1000; // Increase price for large cup
    }
    price *= quantity; // Update price based on quantity
    setSelectedPrice(price);
  };

  const handleProductPress = (product) => {
    setSelectedProduct(product);
    setCupSize('M');
    setQuantity(1);
    setModalVisible(true);
  };

  const handleAddToCart = async () => {
    const item = { ...selectedProduct, cupSize, quantity, price: selectedPrice.toFixed(2) };
    const existingCart = await AsyncStorage.getItem('cart');
    let updatedCart = [];
    if (existingCart) {
      updatedCart = JSON.parse(existingCart);
    }
    updatedCart.push(item);
    await AsyncStorage.setItem('cart', JSON.stringify(updatedCart));
    setModalVisible(false);
    console.log('Added to cart:', item);
    navigation.navigate('CartScreen');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.introTitle} > SCENTIFY PRODUCTS</Text>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {products.map((product) => (
          <TouchableOpacity key={product.id} style={styles.productContainer} onPress={() => handleProductPress(product)}>
            <Image source={product.image} style={styles.productImage} />
            <Text style={styles.productTitle}>{product.title}</Text>
            <Text style={styles.productPrice}>₱{product.price.toFixed(2)}</Text>
            <Text style={styles.starRating}>⭐⭐⭐⭐⭐</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.productDetails}>
              <Image source={selectedProduct?.image} style={styles.productImageModal} />
              <View style={styles.productInfo}>
                <Text style={styles.productTitleModal}>{selectedProduct?.title}</Text>
                <Text style={styles.productPriceModal}>Price: ₱{selectedPrice.toFixed(2)}</Text>
              </View>
            </View>
            <Text style={styles.sectionTitle}>Options</Text>
            <View style={styles.optionsContainer}>
              <View style={styles.option}>
                <Text>Perfume Size:</Text>
                <View style={styles.buttonsContainer}>
                  <TouchableOpacity
                    style={[styles.cupButton, cupSize === 'S' && styles.selectedCup]}
                    onPress={() => setCupSize('S')}
                  >
                    <Text>S</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.cupButton, cupSize === 'M' && styles.selectedCup]}
                    onPress={() => setCupSize('M')}
                  >
                    <Text>M</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.cupButton, cupSize === 'L' && styles.selectedCup]}
                    onPress={() => setCupSize('L')}
                  >
                    <Text>L</Text>
                  </TouchableOpacity>
                </View>
              </View>
             <View style={styles.option}>
                <Text>Quantity:</Text>
                <View style={styles.buttonsContainer}>
                  <Button title="-" onPress={() => setQuantity(quantity > 1 ? quantity - 1 : 1)} color="#5a3114" />
                  <Text>{quantity}</Text>
                  <Button title="+" onPress={() => setQuantity(quantity + 1)} color="#5a3114" />
                </View>
              </View>
            </View>
            <View style={styles.buttonsContainer}>
              <Button title="Add to Cart" onPress={handleAddToCart} color="#5a3114" />
              <Button title="Close" onPress={() => setModalVisible(false)} color="#5a3114" />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EDDACF', // Change background color to black
  },
  scrollContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    alignItems: 'center',
  },
  productContainer: {
    width: 150,
    padding: 10,
    alignItems: 'center',
  },
  productImage: {
    width: 120,
    height: 120,
    marginBottom: 5,
    borderRadius: 10,
  },
  productTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 5,
    color: '#c68f7d', // Change text color to white
  },
  productPrice: {
    fontSize: 14,
    textAlign: 'center',
    color: 'grey',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
  },
  productDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  productImageModal: {
    width: 80,
    height: 80,
    marginRight: 20,
    borderRadius: 10,
  },
  productInfo: {
    flex: 1,
  },
  productTitleModal: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
     // Change text color to white
  },
  productPriceModal: {
    fontSize: 16,
    color: '#c68f7d',
    marginBottom: 10,
    // Change text color to white
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    alignSelf: 'flex-start',
     // Change text color to white
  },
  optionsContainer: {
    marginBottom: 20,
    width: '100%',
  },
  option: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    
  },
  buttonsContainer: {
    
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    width: '80%',
  },
  cupButton: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#c68f7d',
    borderRadius: 5,
    width: 40,
    alignItems: 'center',
  },
  selectedCup: {
    backgroundColor: '#c68f7d',
  },
   starRating: {
    fontSize: 10,
    color: 'gold',
    marginTop: 5,
  },
   introTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    marginTop: 20,
    color: '#c68f7d', // Change text color to white
  },
});

export default HomeScreen;
